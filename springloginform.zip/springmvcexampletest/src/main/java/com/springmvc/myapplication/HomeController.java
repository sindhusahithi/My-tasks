package com.springmvc.myapplication;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 * Handles requests for the application home page.
 */
@Controller
public class HomeController {
	
	
	
	/*
	 * @RequestMapping(value = "/", method = RequestMethod.GET) public String
	 * printWelcome(ModelMap model) {
	 * 
	 * model.addAttribute("message", "Spring 3 MVC Hello World");
	 * 
	 * ApplicationContext context = new
	 * ClassPathXmlApplicationContext("/WEB-INF/spring-web-servlet.xml");
	 * 
	 * HomeServiceTextEditor te =
	 * (HomeServiceTextEditor)context.getBean("textEditor"); te.spellCheck();
	 * 
	 * 
	 * return "register";
	 * 
	 * }
	 */
	
	 @RequestMapping(value = "/", method = RequestMethod.GET)
	  public ModelAndView showRegister(HttpServletRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("register");
	    mav.addObject("user", new User());
	    
	    //Code for IOC an Dependency Injection
	    ApplicationContext context = new ClassPathXmlApplicationContext("/WEB-INF/spring-web-servlet.xml");

		HomeServiceTextEditor te = (HomeServiceTextEditor)context.getBean("textEditor");
	      te.spellCheck();
	    return mav;
	  }
	 
	 
	 
	 @RequestMapping(value = "/registerProcess", method = RequestMethod.POST)
	  public ModelAndView addUser(HttpServletRequest request, HttpServletResponse response,
	  @ModelAttribute("user") User user) {
		 
		 System.out.println("First Name : "+user.getFirstname());
	  
	  return new ModelAndView("welcome", "firstname", user.getFirstname());
	  }

	
	
}

package com.springmvc.myapplication;

public class HomeServiceTextEditor {
	
	 private SpellChecker spellChecker;

	   public HomeServiceTextEditor(SpellChecker spellChecker) {
	      System.out.println("Inside TextEditor constructor." );
	      this.spellChecker = spellChecker;
	   }
	   public void spellCheck() {
	      spellChecker.checkSpelling();
	   }

}
